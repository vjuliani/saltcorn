import json
import time
import uuid


def response(status, body):
    return {
        'statusCode': status,
        'headers': {
            'content-type': 'application/json',
            'cache-control': 'no-store',
            'pragma': 'no-cache',
            'access-control-allow-origin': '*',
            'access-control-allow-headers': 'Authorization,Content-Type,X-Transaction-Id',
            'access-control-allow-methods': 'POST,OPTIONS',
        },
        'body': json.dumps(body),
    }


def normalize_headers(event):
    return {
        str(k).lower(): v
        for k, v in (event.get('headers') or {}).items()
        if k is not None
    }


def extract_authorizer_context(event):
    authorizer = ((event.get('requestContext') or {}).get('authorizer') or {})
    if not isinstance(authorizer, dict):
        return {}
    if authorizer.get('transaction_id'):
        return authorizer
    for key in ('lambda', 'context'):
        nested = authorizer.get(key)
        if isinstance(nested, dict) and nested.get('transaction_id'):
            return nested
    return {}


def handler(event, context):
    # IMPORTANT: checkout never introspects, consumes, revokes, or writes token state.
    # It trusts only the authorization context produced by the Token Guard.
    auth_ctx = extract_authorizer_context(event)
    if not auth_ctx:
        return response(403, {
            'error': 'authorization_context_missing',
            'message': 'Request was not authorized by the Ephemeral Token Guard.',
        })

    if auth_ctx.get('token_state') != 'USED':
        return response(403, {'error': 'invalid_token_guard_state'})

    headers = normalize_headers(event)
    tx_header = headers.get('x-transaction-id')
    authorized_tx = auth_ctx.get('transaction_id')
    if not authorized_tx:
        return response(403, {'error': 'missing_authorized_transaction'})
    if not tx_header:
        return response(400, {'error': 'missing_transaction_id'})
    if tx_header != authorized_tx:
        return response(403, {'error': 'transaction_context_mismatch'})

    try:
        body = json.loads(event.get('body') or '{}')
    except json.JSONDecodeError:
        return response(400, {'error': 'invalid_json'})

    payment_method_token = body.get('payment_method_token')
    if not payment_method_token or not str(payment_method_token).startswith('pm_'):
        return response(400, {'error': 'invalid_payment_method_token'})

    return response(200, {
        'status': 'succeeded',
        'payment_id': f'pay_{uuid.uuid4().hex}',
        'checkout_session_id': auth_ctx.get('session_id'),
        'transaction_id': authorized_tx,
        'amount': int(auth_ctx.get('amount', '0') or 0),
        'currency': auth_ctx.get('currency'),
        'processed_at': int(time.time()),
        'authorization_mode': 'ephemeral-token-guard',
        'token_state': auth_ctx.get('token_state'),
        'provider_revocation': auth_ctx.get('provider_revocation'),
    })
