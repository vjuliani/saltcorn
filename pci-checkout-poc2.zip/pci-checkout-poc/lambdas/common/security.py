import base64
import hashlib
import hmac
import json
import time
import uuid
from typing import Any, Dict

class JwtError(Exception):
    pass


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * ((4 - len(data) % 4) % 4)
    return base64.urlsafe_b64decode((data + padding).encode("ascii"))


def encode_hs256(payload: Dict[str, Any], secret: str, headers: Dict[str, Any] | None = None) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    if headers:
        header.update(headers)
    h = _b64url_encode(json.dumps(header, separators=(",", ":"), sort_keys=True).encode())
    p = _b64url_encode(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
    signing_input = f"{h}.{p}".encode("ascii")
    sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
    return f"{h}.{p}.{_b64url_encode(sig)}"


def decode_hs256(token: str, secret: str, issuer: str | None = None, audience: str | None = None, leeway: int = 5) -> Dict[str, Any]:
    try:
        h, p, s = token.split(".")
        header = json.loads(_b64url_decode(h))
        payload = json.loads(_b64url_decode(p))
    except Exception as exc:
        raise JwtError("malformed_jwt") from exc

    if header.get("alg") != "HS256":
        raise JwtError("unexpected_alg")

    expected = hmac.new(secret.encode(), f"{h}.{p}".encode("ascii"), hashlib.sha256).digest()
    actual = _b64url_decode(s)
    if not hmac.compare_digest(expected, actual):
        raise JwtError("invalid_signature")

    now = int(time.time())
    if "exp" in payload and now > int(payload["exp"]) + leeway:
        raise JwtError("expired")
    if "nbf" in payload and now + leeway < int(payload["nbf"]):
        raise JwtError("not_yet_valid")
    if issuer and payload.get("iss") != issuer:
        raise JwtError("invalid_issuer")
    if audience:
        aud = payload.get("aud")
        audiences = aud if isinstance(aud, list) else [aud]
        if audience not in audiences:
            raise JwtError("invalid_audience")
    return payload


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def random_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def decode_unverified(token: str) -> tuple[Dict[str, Any], Dict[str, Any]]:
    try:
        h, p, _ = token.split('.')
        return json.loads(_b64url_decode(h)), json.loads(_b64url_decode(p))
    except Exception as exc:
        raise JwtError('malformed_jwt') from exc


def validate_claims(payload: Dict[str, Any], issuer: str | None = None, audience: str | None = None, leeway: int = 5) -> Dict[str, Any]:
    now = int(time.time())
    if 'exp' in payload and now > int(payload['exp']) + leeway:
        raise JwtError('expired')
    if 'nbf' in payload and now + leeway < int(payload['nbf']):
        raise JwtError('not_yet_valid')
    if issuer and payload.get('iss') != issuer:
        raise JwtError('invalid_issuer')
    if audience:
        aud = payload.get('aud')
        audiences = aud if isinstance(aud, list) else [aud]
        if audience not in audiences:
            raise JwtError('invalid_audience')
    return payload
