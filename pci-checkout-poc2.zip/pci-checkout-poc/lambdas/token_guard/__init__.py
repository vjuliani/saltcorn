"""Portable Ephemeral Token Guard core."""
