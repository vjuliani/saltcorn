#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BACKEND="${BACKEND:-http://localhost:3002}"
API_BASE="$(cd "$ROOT/infra/terraform" && terraform output -raw api_base_url)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

DEMO=$(curl -sS "$BACKEND/api/demo/token")
MERCHANT_JWT=$(python3 -c 'import json,sys; print(json.load(sys.stdin)["token"])' <<<"$DEMO")

SESSION_CODE=$(curl -sS -o "$TMP/session.json" -w '%{http_code}' -X POST "$BACKEND/api/checkout/session" \
  -H "Authorization: Bearer $MERCHANT_JWT" -H 'Content-Type: application/json' \
  -d '{"amount":1099,"currency":"brl","merchant_reference":"order_browser_flow"}')
echo "Flow 2 - Frontend -> Merchant Backend -> API Gateway /checkout-session: HTTP $SESSION_CODE"
python3 -m json.tool < "$TMP/session.json" || cat "$TMP/session.json"
[[ "$SESSION_CODE" == "201" ]] || exit 1

TOKEN=$(python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("ephemeral_token") or d["client_secret"])' < "$TMP/session.json")
TXN=$(python3 -c 'import json,sys; print(json.load(sys.stdin)["transaction_id"])' < "$TMP/session.json")
PAYMENT_URL=$(python3 -c 'import json,sys; print(json.load(sys.stdin)["payment_api_url"])' < "$TMP/session.json")

echo; echo "Flow 1 - PCI Hosted Fields -> API Gateway /payment -> TOKEN Lambda Authorizer -> Payment Checkout"
echo "Payment URL: $PAYMENT_URL"
PAY_CODE=$(curl -sS -o "$TMP/payment.json" -w '%{http_code}' -X POST "$PAYMENT_URL" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Transaction-Id: $TXN" \
  -H 'Content-Type: application/json' \
  -d '{"payment_method_token":"pm_test_4242"}')
echo "HTTP $PAY_CODE"
python3 -m json.tool < "$TMP/payment.json" || cat "$TMP/payment.json"
[[ "$PAY_CODE" == "200" ]] || exit 1

echo; echo "Replay through API Gateway (expected 401/403):"
REPLAY=$(curl -sS -o "$TMP/replay.json" -w '%{http_code}' -X POST "$PAYMENT_URL" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Transaction-Id: $TXN" \
  -H 'Content-Type: application/json' \
  -d '{"payment_method_token":"pm_test_4242"}')
echo "HTTP $REPLAY"
python3 -m json.tool < "$TMP/replay.json" || cat "$TMP/replay.json"
case "$REPLAY" in 401|403) ;; *) exit 1 ;; esac

echo "PASS: payment never crossed the Merchant Backend; PCI Hosted Fields submitted directly to API Gateway /payment."
