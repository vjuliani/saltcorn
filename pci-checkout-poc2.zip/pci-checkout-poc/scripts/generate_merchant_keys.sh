#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SECRETS_DIR="${MERCHANT_SECRETS_DIR:-$ROOT/secrets}"
PRIVATE_KEY="$SECRETS_DIR/merchant-private.pem"
PUBLIC_KEY="$SECRETS_DIR/merchant-public.pem"
mkdir -p "$SECRETS_DIR"
if [[ ! -s "$PRIVATE_KEY" ]]; then
  echo "Generating local merchant RSA private key..."
  openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out "$PRIVATE_KEY" >/dev/null 2>&1
  chmod 600 "$PRIVATE_KEY"
fi
if [[ ! -s "$PUBLIC_KEY" ]]; then
  openssl pkey -in "$PRIVATE_KEY" -pubout -out "$PUBLIC_KEY" >/dev/null 2>&1
fi
chmod 644 "$PUBLIC_KEY"
echo "Merchant demo keys ready in $SECRETS_DIR"
