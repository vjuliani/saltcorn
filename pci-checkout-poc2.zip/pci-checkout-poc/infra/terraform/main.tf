provider "aws" {
  access_key                  = "test"
  secret_key                  = "test"
  region                      = var.region
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  s3_use_path_style           = true

  endpoints {
    apigateway = "http://localhost:4566"
    dynamodb   = "http://localhost:4566"
    iam        = "http://localhost:4566"
    lambda     = "http://localhost:4566"
    sts        = "http://localhost:4566"
    logs       = "http://localhost:4566"
  }
}

locals {
  project_root     = "${path.module}/../.."
  common_security  = file("${local.project_root}/lambdas/common/security.py")
  hydra_public_url = "http://hydra:4444"
  hydra_admin_url  = "http://hydra:4445"
}

# -----------------------------------------------------------------------------
# Lambda packages
# -----------------------------------------------------------------------------

data "archive_file" "create_session" {
  type        = "zip"
  output_path = "${path.module}/create_session.zip"

  source {
    content  = file("${local.project_root}/lambdas/create_session/app.py")
    filename = "app.py"
  }

  source {
    content  = local.common_security
    filename = "security.py"
  }
}

data "archive_file" "authorizer" {
  type        = "zip"
  output_path = "${path.module}/authorizer.zip"

  source {
    content  = file("${local.project_root}/lambdas/authorizer/app.py")
    filename = "app.py"
  }

  source {
    content  = local.common_security
    filename = "security.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/__init__.py")
    filename = "token_guard/__init__.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/errors.py")
    filename = "token_guard/errors.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/models.py")
    filename = "token_guard/models.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/ports.py")
    filename = "token_guard/ports.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/core.py")
    filename = "token_guard/core.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/providers/__init__.py")
    filename = "token_guard/providers/__init__.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/providers/hydra.py")
    filename = "token_guard/providers/hydra.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/stores/__init__.py")
    filename = "token_guard/stores/__init__.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/stores/dynamodb.py")
    filename = "token_guard/stores/dynamodb.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/adapters/__init__.py")
    filename = "token_guard/adapters/__init__.py"
  }

  source {
    content  = file("${local.project_root}/lambdas/token_guard/adapters/aws_request.py")
    filename = "token_guard/adapters/aws_request.py"
  }
}

data "archive_file" "checkout" {
  type        = "zip"
  output_path = "${path.module}/checkout.zip"

  source {
    content  = file("${local.project_root}/lambdas/checkout/app.py")
    filename = "app.py"
  }
}

# -----------------------------------------------------------------------------
# Persistence
# Business session state and one-time-token replay state are intentionally split.
# -----------------------------------------------------------------------------

resource "aws_dynamodb_table" "sessions" {
  name         = "pci-checkout-sessions"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "pk"
  range_key    = "sk"

  attribute {
    name = "pk"
    type = "S"
  }

  attribute {
    name = "sk"
    type = "S"
  }

  ttl {
    attribute_name = "ttl"
    enabled        = true
  }
}

resource "aws_dynamodb_table" "token_ledger" {
  name         = "pci-ephemeral-token-ledger"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "token_hash"

  attribute {
    name = "token_hash"
    type = "S"
  }

  ttl {
    attribute_name = "ttl"
    enabled        = true
  }
}

# -----------------------------------------------------------------------------
# IAM - least privilege keeps the checkout domain isolated from token state.
# -----------------------------------------------------------------------------

locals {
  lambda_assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
    }]
  })

  logging_statement = {
    Effect   = "Allow"
    Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
    Resource = "*"
  }
}

resource "aws_iam_role" "create_session" {
  name               = "pci-create-session-role"
  assume_role_policy = local.lambda_assume_role_policy
}

resource "aws_iam_role_policy" "create_session" {
  name = "pci-create-session-policy"
  role = aws_iam_role.create_session.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = ["dynamodb:PutItem", "dynamodb:TransactWriteItems"]
        Resource = [
          aws_dynamodb_table.sessions.arn,
          aws_dynamodb_table.token_ledger.arn,
        ]
      },
      local.logging_statement,
    ]
  })
}

resource "aws_iam_role" "authorizer" {
  name               = "pci-token-guard-role"
  assume_role_policy = local.lambda_assume_role_policy
}

resource "aws_iam_role_policy" "authorizer" {
  name = "pci-token-guard-policy"
  role = aws_iam_role.authorizer.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["dynamodb:GetItem", "dynamodb:UpdateItem"]
        Resource = aws_dynamodb_table.token_ledger.arn
      },
      local.logging_statement,
    ]
  })
}

resource "aws_iam_role" "checkout" {
  name               = "pci-checkout-domain-role"
  assume_role_policy = local.lambda_assume_role_policy
}

resource "aws_iam_role_policy" "checkout" {
  name = "pci-checkout-domain-policy"
  role = aws_iam_role.checkout.id
  policy = jsonencode({
    Version   = "2012-10-17"
    Statement = [local.logging_statement]
  })
}

# -----------------------------------------------------------------------------
# Lambdas
# -----------------------------------------------------------------------------

resource "aws_lambda_function" "create_session" {
  function_name    = "pci-create-checkout-session"
  role             = aws_iam_role.create_session.arn
  runtime          = "python3.10"
  handler          = "app.handler"
  filename         = data.archive_file.create_session.output_path
  source_code_hash = data.archive_file.create_session.output_base64sha256
  timeout          = 10

  environment {
    variables = {
      SESSION_TABLE         = aws_dynamodb_table.sessions.name
      TOKEN_LEDGER_TABLE    = aws_dynamodb_table.token_ledger.name
      MERCHANT_JWT_ISSUER   = "merchant-demo"
      MERCHANT_JWT_AUDIENCE = "checkout-session-service"
      SESSION_TTL_SECONDS   = tostring(var.session_ttl_seconds)
      AWS_ENDPOINT_URL      = "http://localhost.localstack.cloud:4566"
      HYDRA_PUBLIC_URL      = local.hydra_public_url
      HYDRA_CLIENT_ID       = var.hydra_client_id
      HYDRA_CLIENT_SECRET   = var.hydra_client_secret
      HYDRA_SCOPE           = "payment.execute"
      LOCAL_DIAGNOSTICS     = "true"
    }
  }
}

resource "aws_lambda_function" "authorizer" {
  function_name    = "pci-ephemeral-token-guard"
  role             = aws_iam_role.authorizer.arn
  runtime          = "python3.10"
  handler          = "app.handler"
  filename         = data.archive_file.authorizer.output_path
  source_code_hash = data.archive_file.authorizer.output_base64sha256
  timeout          = 10

  environment {
    variables = {
      TOKEN_LEDGER_TABLE  = aws_dynamodb_table.token_ledger.name
      AWS_ENDPOINT_URL    = "http://localhost.localstack.cloud:4566"
      HYDRA_PUBLIC_URL    = local.hydra_public_url
      HYDRA_ADMIN_URL     = local.hydra_admin_url
      HYDRA_CLIENT_ID     = var.hydra_client_id
      HYDRA_CLIENT_SECRET = var.hydra_client_secret
      HYDRA_SCOPE         = "payment.execute"
    }
  }
}

resource "aws_lambda_function" "checkout" {
  function_name    = "pci-payment-checkout"
  role             = aws_iam_role.checkout.arn
  runtime          = "python3.10"
  handler          = "app.handler"
  filename         = data.archive_file.checkout.output_path
  source_code_hash = data.archive_file.checkout.output_base64sha256
  timeout          = 10
}

# -----------------------------------------------------------------------------
# API Gateway REST API
# -----------------------------------------------------------------------------

resource "aws_api_gateway_rest_api" "checkout" {
  name        = "pci-checkout-api"
  description = "Direct PCI payment POC with opaque single-use token and Lambda Authorizer Token Guard"
}

resource "aws_api_gateway_resource" "sessions" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  parent_id   = aws_api_gateway_rest_api.checkout.root_resource_id
  path_part   = "checkout-session"
}

resource "aws_api_gateway_resource" "confirm" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  parent_id   = aws_api_gateway_rest_api.checkout.root_resource_id
  path_part   = "payment"
}

resource "aws_api_gateway_method" "create_session" {
  rest_api_id   = aws_api_gateway_rest_api.checkout.id
  resource_id   = aws_api_gateway_resource.sessions.id
  http_method   = "POST"
  authorization = "NONE"
}

resource "aws_api_gateway_integration" "create_session" {
  rest_api_id             = aws_api_gateway_rest_api.checkout.id
  resource_id             = aws_api_gateway_resource.sessions.id
  http_method             = aws_api_gateway_method.create_session.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = "arn:aws:apigateway:${var.region}:lambda:path/2015-03-31/functions/${aws_lambda_function.create_session.arn}/invocations"
}

resource "aws_api_gateway_authorizer" "checkout" {
  name                             = "ephemeral-token-guard"
  rest_api_id                      = aws_api_gateway_rest_api.checkout.id
  authorizer_uri                   = "arn:aws:apigateway:${var.region}:lambda:path/2015-03-31/functions/${aws_lambda_function.authorizer.arn}/invocations"
  authorizer_result_ttl_in_seconds = 0
  identity_source                  = "method.request.header.Authorization"
  type                             = "TOKEN"
}

resource "aws_api_gateway_method" "checkout" {
  rest_api_id   = aws_api_gateway_rest_api.checkout.id
  resource_id   = aws_api_gateway_resource.confirm.id
  http_method   = "POST"
  authorization = "CUSTOM"
  authorizer_id = aws_api_gateway_authorizer.checkout.id

  request_parameters = {
    "method.request.header.Authorization"    = true
    "method.request.header.X-Transaction-Id" = true
  }
}

resource "aws_api_gateway_integration" "checkout" {
  rest_api_id             = aws_api_gateway_rest_api.checkout.id
  resource_id             = aws_api_gateway_resource.confirm.id
  http_method             = aws_api_gateway_method.checkout.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = "arn:aws:apigateway:${var.region}:lambda:path/2015-03-31/functions/${aws_lambda_function.checkout.arn}/invocations"
}

# CORS preflight
resource "aws_api_gateway_method" "sessions_options" {
  rest_api_id   = aws_api_gateway_rest_api.checkout.id
  resource_id   = aws_api_gateway_resource.sessions.id
  http_method   = "OPTIONS"
  authorization = "NONE"
}

resource "aws_api_gateway_integration" "sessions_options" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  resource_id = aws_api_gateway_resource.sessions.id
  http_method = aws_api_gateway_method.sessions_options.http_method
  type        = "MOCK"
  request_templates = {
    "application/json" = "{\"statusCode\": 200}"
  }
}

resource "aws_api_gateway_method_response" "sessions_options_200" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  resource_id = aws_api_gateway_resource.sessions.id
  http_method = aws_api_gateway_method.sessions_options.http_method
  status_code = "200"
  response_parameters = {
    "method.response.header.Access-Control-Allow-Headers" = true
    "method.response.header.Access-Control-Allow-Methods" = true
    "method.response.header.Access-Control-Allow-Origin"  = true
  }
}

resource "aws_api_gateway_integration_response" "sessions_options_200" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  resource_id = aws_api_gateway_resource.sessions.id
  http_method = aws_api_gateway_method.sessions_options.http_method
  status_code = aws_api_gateway_method_response.sessions_options_200.status_code
  response_parameters = {
    "method.response.header.Access-Control-Allow-Headers" = "'Authorization,Content-Type,X-Transaction-Id'"
    "method.response.header.Access-Control-Allow-Methods" = "'POST,OPTIONS'"
    "method.response.header.Access-Control-Allow-Origin"  = "'*'"
  }
  depends_on = [aws_api_gateway_integration.sessions_options]
}

resource "aws_api_gateway_method" "confirm_options" {
  rest_api_id   = aws_api_gateway_rest_api.checkout.id
  resource_id   = aws_api_gateway_resource.confirm.id
  http_method   = "OPTIONS"
  authorization = "NONE"
}

resource "aws_api_gateway_integration" "confirm_options" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  resource_id = aws_api_gateway_resource.confirm.id
  http_method = aws_api_gateway_method.confirm_options.http_method
  type        = "MOCK"
  request_templates = {
    "application/json" = "{\"statusCode\": 200}"
  }
}

resource "aws_api_gateway_method_response" "confirm_options_200" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  resource_id = aws_api_gateway_resource.confirm.id
  http_method = aws_api_gateway_method.confirm_options.http_method
  status_code = "200"
  response_parameters = {
    "method.response.header.Access-Control-Allow-Headers" = true
    "method.response.header.Access-Control-Allow-Methods" = true
    "method.response.header.Access-Control-Allow-Origin"  = true
  }
}

resource "aws_api_gateway_integration_response" "confirm_options_200" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id
  resource_id = aws_api_gateway_resource.confirm.id
  http_method = aws_api_gateway_method.confirm_options.http_method
  status_code = aws_api_gateway_method_response.confirm_options_200.status_code
  response_parameters = {
    "method.response.header.Access-Control-Allow-Headers" = "'Authorization,Content-Type,X-Transaction-Id'"
    "method.response.header.Access-Control-Allow-Methods" = "'POST,OPTIONS'"
    "method.response.header.Access-Control-Allow-Origin"  = "'*'"
  }
  depends_on = [aws_api_gateway_integration.confirm_options]
}

resource "aws_api_gateway_deployment" "checkout" {
  rest_api_id = aws_api_gateway_rest_api.checkout.id

  triggers = {
    redeployment = sha1(jsonencode({
      authorizer_id       = aws_api_gateway_authorizer.checkout.id
      authorizer_uri      = aws_api_gateway_authorizer.checkout.authorizer_uri
      authorizer_type     = aws_api_gateway_authorizer.checkout.type
      authorizer_identity = aws_api_gateway_authorizer.checkout.identity_source
      authorization       = aws_api_gateway_method.checkout.authorization
      checkout_method     = aws_api_gateway_method.checkout.http_method
      checkout_uri        = aws_api_gateway_integration.checkout.uri
      create_session_uri  = aws_api_gateway_integration.create_session.uri
      authorizer_permission = aws_lambda_permission.authorizer_apigw.statement_id
      checkout_permission   = aws_lambda_permission.checkout_apigw.statement_id
    }))
  }

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [
    aws_lambda_permission.create_session_apigw,
    aws_lambda_permission.checkout_apigw,
    aws_lambda_permission.authorizer_apigw,
    aws_api_gateway_authorizer.checkout,
    aws_api_gateway_method.create_session,
    aws_api_gateway_method.checkout,
    aws_api_gateway_method.sessions_options,
    aws_api_gateway_method.confirm_options,
    aws_api_gateway_integration.create_session,
    aws_api_gateway_integration.checkout,
    aws_api_gateway_integration.sessions_options,
    aws_api_gateway_integration.confirm_options,
    aws_api_gateway_integration_response.sessions_options_200,
    aws_api_gateway_integration_response.confirm_options_200,
  ]
}

resource "aws_api_gateway_stage" "local" {
  deployment_id = aws_api_gateway_deployment.checkout.id
  rest_api_id   = aws_api_gateway_rest_api.checkout.id
  stage_name    = "local"
}

resource "aws_lambda_permission" "create_session_apigw" {
  statement_id  = "AllowCreateSessionFromApiGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.create_session.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.checkout.execution_arn}/*/*"
}

resource "aws_lambda_permission" "checkout_apigw" {
  statement_id  = "AllowCheckoutFromApiGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.checkout.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.checkout.execution_arn}/*/*"
}

resource "aws_lambda_permission" "authorizer_apigw" {
  statement_id  = "AllowTokenGuardFromApiGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.authorizer.function_name
  principal     = "apigateway.amazonaws.com"
}


