variable "region" {
  type        = string
  description = "AWS region used by LocalStack resources."
  default     = "us-east-1"
}

variable "hydra_client_id" {
  type        = string
  description = "Hydra OAuth2 client used for the RFC 7523 JWT Bearer Grant."
  default     = "pci-checkout-exchange"
}

variable "hydra_client_secret" {
  type        = string
  description = "Development-only Hydra OAuth2 client secret."
  default     = "dev-pci-checkout-hydra-secret-please-change-32bytes"
  sensitive   = true
}

variable "session_ttl_seconds" {
  type        = number
  description = "Maximum lifetime recorded for a checkout session. Hydra access-token TTL must be equal or shorter."
  default     = 120
}
